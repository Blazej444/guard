This script will display information about the account:
```
Username: username
SteamId: 76561199000000000
GuardCode: BJ8XG
```

All you have to do is put the mafile in the mafiles folder
